#pragma once

// rarproxy.cpp
class rconnect_interface;
extern "C" _declspec(dllexport) rconnect_interface* Rconnect(rconnect_interface *connect);
