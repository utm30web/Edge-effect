#pragma once

SEXP R_export2dataset(SEXP path, SEXP sargs);
