# Get geoprocessing environment settings
#' @export
arc.env <- function ()
{
  .call_proxy("arc_getEnv")
}
